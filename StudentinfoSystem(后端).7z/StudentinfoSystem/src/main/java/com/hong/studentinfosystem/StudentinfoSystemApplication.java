package com.hong.studentinfosystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentinfoSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentinfoSystemApplication.class, args);
    }

}
