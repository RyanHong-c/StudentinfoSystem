package com.hong.studentinfosystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentinfoSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
